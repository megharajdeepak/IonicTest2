import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.page.html',
  styleUrls: ['./filter.page.scss'],
})
export class FilterPage implements OnInit {

  constructor(private modalController: ModalController) { }

  ngOnInit() {
  }
  
  ageRange:any = {lower: 18, upper: 70};

  change() {
    console.log(this.ageRange);
  }

  dismissModal() {
    this.modalController.dismiss({username:'username', 'pwd':'pwd'});
  }
  

}
