import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ParentDetailsPageRoutingModule } from './parent-details-routing.module';

import { ParentDetailsPage } from './parent-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ParentDetailsPageRoutingModule
  ],
  declarations: [ParentDetailsPage]
})
export class ParentDetailsPageModule {}
