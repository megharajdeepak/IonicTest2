import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-parent-details',
  templateUrl: './parent-details.page.html',
  styleUrls: ['./parent-details.page.scss'],
})
export class ParentDetailsPage implements OnInit {

  constructor(
    private activatedRoute: ActivatedRoute,
    private router:Router
  ) { }

  parent_id:number;
  parent_details:any;

  ngOnInit() {
    this.parent_id = Number(this.activatedRoute.snapshot.paramMap.get('parent_id'));

    //call api to get parent details by passing person.parent_id
    //and store that row result in parent_details variable like below
    this.parent_details = {
      mobile_number:9900579871, name:"Deepak MS", photo:'longstring', 
      dob:'1975-12-12', age:45, address:'some address', village_name:'Bali',
      profession_name:'Real estate', email:'megharajdeepak@gmail.com', 
      spouse_name:'Ritu', 'has_children':1
    }
  }

  showChildren() {
    this.router.navigate(['/children-list/'+this.parent_id]);
  }

}
