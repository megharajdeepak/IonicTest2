import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ParentDetailsPage } from './parent-details.page';

const routes: Routes = [
  {
    path: '',
    component: ParentDetailsPage
  },
  {
    path: ':parent_id',
    component: ParentDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ParentDetailsPageRoutingModule {}
