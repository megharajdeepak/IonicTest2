import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-children-list',
  templateUrl: './children-list.page.html',
  styleUrls: ['./children-list.page.scss'],
})
export class ChildrenListPage implements OnInit {

  constructor(
    private activatedRoute:ActivatedRoute
  ) { }

  parent_id:number;
  children:any[];

  ngOnInit() {
    this.parent_id = Number(this.activatedRoute.snapshot.paramMap.get('parent_id'));

    //call api to get parent details by passing person.parent_id
    //and store that row result in parent_details variable like below
    this.children = [
      {child_name:'Vinaya', child_age:10, child_gender:'f'},
      {child_name:'Rakesh', child_age:13, child_gender:'m'},
      {child_name:'Rishitha', child_age:18, child_gender:'f'}
    ];
    
  }

}
