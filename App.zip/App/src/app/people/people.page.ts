import { Router } from '@angular/router';
import { FilterPage } from './../filter/filter.page';
import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-people',
  templateUrl: './people.page.html',
  styleUrls: ['./people.page.scss'],
})
export class PeoplePage implements OnInit {

  constructor(
    private modalController:ModalController,
    private router:Router
  ) { }

  async presentModal() {
    const modal = await this.modalController.create({
      component: FilterPage
    });
    
    modal.onDidDismiss()
      .then((data) => {
        const user = data['data']; // Here's your selected user!
        console.log(data);
    });
    
    return await modal.present();
  }

  defaultTabValue:number = 1;

  people:any = [
    {parent_id:1, name:'Ranjan Jain', is_parent:1, village_name:'Bali', 'child_age':null, child_gender:null},
    {parent_id:2, name:'Rajesh Sharma', is_parent:1, village_name:'Bali', 'child_age':null, child_gender:null},
    {parent_id:1, name:'Ankit', is_parent:0, village_name:'Bali', 'child_age':12, child_gender:'m'},
    {parent_id:1, name:'Vikas', is_parent:0, village_name:'Bali', 'child_age':19, child_gender:'m'},
    {parent_id:2, name:'Sushma', is_parent:0, village_name:'Bali', 'child_age':29, child_gender:'f'},
    {parent_id:2, name:'Swathi', is_parent:0, village_name:'Bali', 'child_age':24, child_gender:'f'},
    {parent_id:2, name:'Ram', is_parent:0, village_name:'Bali', 'child_age':21, child_gender:'m'},
  ];

  married:any = [];
  ngOnInit() {

  }

  segmentChanged(event) {
    //event.detail.value;
  }

  

  personClick(person:any) {
    console.log(person);
    if(person['is_parent'] === 1) {
      this.router.navigate(['/parent-details/'+person['parent_id']]);
    }
  }

}
